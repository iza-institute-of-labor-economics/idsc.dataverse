## Demo code using idsc.dataverse

**About**

This module reads metadata and files of datasets from a dataverse ```dataverse.example1.com``` and writes them into ```~/.idsc/dataverse/api/dataverse.example1.com```. It then exports the local copy of the dataverse from ```~/.idsc/dataverse/api/dataverse.example1.com``` to ```~/.idsc/.cache/dataverse.example2.com``` so that one can the upload them to ```dataverse.example2.com```. It can delete and publish datasets as well as modify the PID of a dataset for when you e.g. are not on datacite etc. It can also create, delete and publish dataverses.

The code in the *idsc.dataverse* was written while learning the Harvard dataverse search and native APIs. It grew in an attempt to quickly learn how to program the API, understand dataverse itself, fix issues particular to our dataverse instance and do necessary dataverse chores aimed at shortening launch time. The code is in a very early stage and does not attempt a comprehensive python implementation of the various Harvard Dataverse APIs (as e.g. https://github.com/IQSS/dataverse-client-python does). It is placed here in the hope that others might need to do similar chores. 

**Setup**

Keep your credentials in files (e.g. in the same folder as this code) .env.prod, .env.dev, .env.demo1 and .env.demo2 which might look like this:

```
baseURL=https://Production Instance URL
myKey=XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX
```

```
baseURL=https://Development Instance URL 
myKey=XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX
```

```
baseURL=https://Demo1 Instance URL 
myKey=XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX
```

```
baseURL=https://Demo2 Instance URL 
myKey=XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX
```

In our case we clone a Production Instance into a Development one to play writing/deleting/resetting games with and two instances Demo1 and Demo2 to play federation games with. In your case these might be different including just one instance. You might use the module to create an offline back up of your inventory for example. 

You might contact us at idsc@iza.org if you wish to be informed when we launch or you made use of this code. 

**Load your credentials in a dictionary**


```python
import importlib    
import json

importlib.reload(api)                     
#importlib.reload(utils)                   

from dotenv import dotenv_values
config = {
    "prod":{**dotenv_values(".env.prod")}, 
    "dev":{**dotenv_values(".env.dev")},  
    "demo1":{**dotenv_values(".env.demo1")},  
    "demo2": {**dotenv_values(".env.demo2")}
}


#make a copy for demo
import copy
public_config = copy.deepcopy(config)

#privacy mods
for key in public_config.keys():
    public_config[key]["myKey"] = "XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX"
    public_config[key]["baseURL"] = f"https://{key} url"

    
print(json.dumps(public_config,indent=4))

```

    {
        "prod": {
            "baseURL": "https://prod url",
            "myKey": "XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX"
        },
        "dev": {
            "baseURL": "https://dev url",
            "myKey": "XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX"
        },
        "demo1": {
            "baseURL": "https://demo1 url",
            "myKey": "XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX"
        },
        "demo2": {
            "baseURL": "https://demo2 url",
            "myKey": "XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX"
        }
    }


**Instantiate the API class for each Dataverse instance**


```python
from idsc.dataverse import api

prod = api.API(config["prod"]["baseURL"], config["prod"]["myKey"])
dev = api.API(config["dev"]["baseURL"], config["dev"]["myKey"])
dv1 = api.API(config["demo1"]["baseURL"], config["demo1"]["myKey"])
dv2 = api.API(config["demo2"]["baseURL"], config["demo2"]["myKey"])

#e.g.
print("Production Count",prod.getTotalCount())
#e.g.
print("Demo1 count",dv1.getTotalCount())
```

    Production Count 25
    Demo1 count 12


**List Dataverse**


```python
print("Production Listing")
print(json.dumps(prod.getDVList(),indent=4))
```

    Production Listing
    {
        "root": "IDSC-Dataverse",
        "children": [
            {
                "type": "dataverse",
                "id": 2,
                "title": "IZA - Institute of Labor Economics"
            },
            {
                "type": "dataverse",
                "id": 3,
                "title": "briq - Behavior and Inequality Research Institute"
            },
            {
                "type": "dataverse",
                "id": 5,
                "title": "G2LM-LIC - Gender, Growth and Labour Markets in Low-Income Countries"
            }
        ]
    }
    Demo1 Listing
    {
        "root": "IDSC-Dataverse",
        "children": [
            {
                "type": "dataverse",
                "id": 2,
                "title": "IZA - Institute of Labor Economics"
            },
            {
                "type": "dataverse",
                "id": 3,
                "title": "briq - Behavior and Inequality Research Institute"
            },
            {
                "type": "dataverse",
                "id": 5,
                "title": "G2LM-LIC - Gender, Growth and Labour Markets in Low-Income Countries"
            }
        ]
    }


**Make a dictionary of PIDs of datasets and their respective dataverse**


```python
import json
pid2dataverse = prod.getPIDs()
print(f"pid2dataverse ({prod.host}) = \n", json.dumps(pid2dataverse,indent=4))
```

    pid2dataverse (https://dataverse.iza.org) = 
     {
        "doi:10.15185/glmlic.697.1": "G2LM-LIC",
        "doi:10.15185/glmlic.687.1": "G2LM-LIC",
        "doi:10.15185/glmlic.071.1": "G2LM-LIC",
        "doi:10.15185/glmlic.3416.1": "G2LM-LIC",
        "doi:10.15185/191432411": "briq",
        "doi:10.15185/glmlic.696.1": "G2LM-LIC",
        "doi:10.15185/j.geb.2022.10.008": "IZA",
        "doi:10.15185/glmlic.399.1": "G2LM-LIC",
        "doi:10.15185/izadp.7971.1": "IZA",
        "doi:10.15185/glmlic.700.1": "G2LM-LIC",
        "doi:10.15185/glmlic.238.1": "G2LM-LIC",
        "doi:10.5072/FK2/LMCCQU": "G2LM-LIC",
        "doi:10.15185/glmlic.176.1": "G2LM-LIC",
        "doi:10.15185/glmlic.620.1": "G2LM-LIC",
        "doi:10.15185/glmlic.582.1": "G2LM-LIC",
        "doi:10.15185/glmlic.400.1": "G2LM-LIC",
        "doi:10.15185/izadp.8337.1": "IZA",
        "doi:10.15185/glmlic.330.1": "G2LM-LIC",
        "doi:10.15185/izarr.126.1": "IZA",
        "doi:10.15185/glmlic.720466.1": "G2LM-LIC",
        "doi:10.15185/izarr.123.1": "IZA",
        "doi:10.15185/glmlic.406.1": "G2LM-LIC",
        "doi:10.15185/glmlic.707.1": "G2LM-LIC",
        "doi:10.15185/glmlic.704.1": "G2LM-LIC",
        "doi:10.15185/izadp.15011.1": "IZA"
    }


**Get an entire dataverse into ~/.idsc**


```python
pid2dataverse = prod.getPIDs()
for pid in pid2dataverse.keys():
    prod.getMetadata(pid)
    prod.getDatasetFiles(pid)
    
```

    getDatasetFiles:Failed to download files for doi:10.15185/glmlic.697.1. Status code: 400
    getDatasetFiles:Failed to download files for doi:10.15185/glmlic.687.1. Status code: 400
    getDatasetFiles:Failed to download files for doi:10.5072/FK2/LMCCQU. Status code: 400


**Check ~/.idsc**


```python
#!ls -R ~/.idsc/dataverse/api/dataverse.iza.org
!find ~/.idsc -maxdepth 4 -type d -exec ls -ld "{}" \;
```

    drwxr-xr-x  4 askitas  staff  128 Oct 23 11:33 [34m/Users/askitas/.idsc[m[m
    drwxr-xr-x  3 askitas  staff  96 Oct 23 11:33 [34m/Users/askitas/.idsc/dataverse[m[m
    drwxr-xr-x  6 askitas  staff  192 Oct 23 11:33 [34m/Users/askitas/.idsc/dataverse/api[m[m
    drwxr-xr-x  2 askitas  staff  64 Oct 23 11:33 [34m/Users/askitas/.idsc/dataverse/api/demodv1.iza.org[m[m
    drwxr-xr-x  3 askitas  staff  96 Oct 23 11:40 [34m/Users/askitas/.idsc/dataverse/api/dataversedev.iza.org[m[m
    drwxr-xr-x  3 askitas  staff  96 Oct 23 11:40 [34m/Users/askitas/.idsc/dataverse/api/dataversedev.iza.org/doi[m[m
    drwxr-xr-x  2 askitas  staff  64 Oct 23 11:33 [34m/Users/askitas/.idsc/dataverse/api/demodv2.iza.org[m[m
    drwxr-xr-x  3 askitas  staff  96 Oct 23 11:36 [34m/Users/askitas/.idsc/dataverse/api/dataverse.iza.org[m[m
    drwxr-xr-x  4 askitas  staff  128 Oct 23 11:37 [34m/Users/askitas/.idsc/dataverse/api/dataverse.iza.org/doi[m[m
    drwxr-xr-x  3 askitas  staff  96 Oct 23 11:37 [34m/Users/askitas/.idsc/.cache[m[m
    drwxr-xr-x  3 askitas  staff  96 Oct 23 11:36 [34m/Users/askitas/.idsc/.cache/dataversedev.iza.org[m[m
    drwxr-xr-x  4 askitas  staff  128 Oct 23 11:37 [34m/Users/askitas/.idsc/.cache/dataversedev.iza.org/doi[m[m
    drwxr-xr-x  3 askitas  staff  96 Oct 23 11:37 [34m/Users/askitas/.idsc/.cache/dataversedev.iza.org/doi/10.5072[m[m
    drwxr-xr-x  26 askitas  staff  832 Oct 23 11:37 [34m/Users/askitas/.idsc/.cache/dataversedev.iza.org/doi/10.15185[m[m


**Export datasets from prod for ingesting them into de**


```python
prod.exportDataFor("https://dataversedev.iza.org")
```

    exportDataFor: copied all to /Users/askitas/.idsc/.cache/dataversedev.iza.org


**Reset the dev dataverse**


```python
pid2dataverse_dev = dev.getPIDs()
for pid in pid2dataverse_dev.keys():
    dev.deleteDataset(pid)
```

    deleteDataset: Request was successful. The resource has been deleted.
    deleteDataset: Request was successful. The resource has been deleted.
    deleteDataset: Request was successful. The resource has been deleted.
    deleteDataset: Request was successful. The resource has been deleted.
    deleteDataset: Request was successful. The resource has been deleted.
    deleteDataset: Request was successful. The resource has been deleted.
    deleteDataset: Request was successful. The resource has been deleted.
    deleteDataset: Request was successful. The resource has been deleted.
    deleteDataset: Request was successful. The resource has been deleted.
    deleteDataset: Request was successful. The resource has been deleted.
    deleteDataset: Request was successful. The resource has been deleted.
    deleteDataset: Request was successful. The resource has been deleted.
    deleteDataset: Request was successful. The resource has been deleted.
    deleteDataset: Request was successful. The resource has been deleted.
    deleteDataset: Request was successful. The resource has been deleted.
    deleteDataset: Request was successful. The resource has been deleted.
    deleteDataset: Request was successful. The resource has been deleted.
    deleteDataset: Request was successful. The resource has been deleted.
    deleteDataset: Request was successful. The resource has been deleted.
    deleteDataset: Request was successful. The resource has been deleted.
    deleteDataset: Request was successful. The resource has been deleted.
    deleteDataset: Request was successful. The resource has been deleted.
    deleteDataset: Request was successful. The resource has been deleted.
    deleteDataset: Request was successful. The resource has been deleted.
    deleteDataset: Request was successful. The resource has been deleted.


**Upload prod to dev and publish**


```python
import os
for pid, dataverse in pid2dataverse.items():
    
    #pid_type, prefix, identifier, identifier4path = dev.disassemblePID(pid)
        
    print("---------------------------")
    print("Creating ",pid)
    
    dev.createDataset(pid,dataverse)
    dev.uploadFiles(pid)
    dev.publishDataset(pid)
  
```

    ---------------------------
    Creating  doi:10.15185/glmlic.697.1
    publishDataset: Request was successful.
    publishDataset : {"status":"OK","data":{"id":340,"identifier":"glmlic.697.1","persistentUrl":"https://doi.org/10.15185/glmlic.697.1","protocol":"doi","authority":"10.15185","publisher":"DEV - Research Data Center of IZA (IDSC)","storageIdentifier":"local://10.15185/glmlic.697.1"}}
    ---------------------------
    Creating  doi:10.15185/glmlic.687.1
    publishDataset: Request was successful.
    publishDataset : {"status":"OK","data":{"id":341,"identifier":"glmlic.687.1","persistentUrl":"https://doi.org/10.15185/glmlic.687.1","protocol":"doi","authority":"10.15185","publisher":"DEV - Research Data Center of IZA (IDSC)","storageIdentifier":"local://10.15185/glmlic.687.1"}}
    ---------------------------
    Creating  doi:10.15185/glmlic.071.1
    publishDataset: Request was successful.
    publishDataset : {"status":"OK","data":{"id":342,"identifier":"glmlic.071.1","persistentUrl":"https://doi.org/10.15185/glmlic.071.1","protocol":"doi","authority":"10.15185","publisher":"DEV - Research Data Center of IZA (IDSC)","storageIdentifier":"local://10.15185/glmlic.071.1"}}
    ---------------------------
    Creating  doi:10.15185/glmlic.3416.1
    publishDataset: Request was successful.
    publishDataset : {"status":"OK","data":{"id":345,"identifier":"glmlic.3416.1","persistentUrl":"https://doi.org/10.15185/glmlic.3416.1","protocol":"doi","authority":"10.15185","publisher":"DEV - Research Data Center of IZA (IDSC)","storageIdentifier":"local://10.15185/glmlic.3416.1"}}
    ---------------------------
    Creating  doi:10.15185/191432411
    publishDataset: Request was successful.
    publishDataset : {"status":"OK","data":{"id":348,"identifier":"191432411","persistentUrl":"https://doi.org/10.15185/191432411","protocol":"doi","authority":"10.15185","publisher":"DEV - Research Data Center of IZA (IDSC)","storageIdentifier":"local://10.15185/191432411"}}
    ---------------------------
    Creating  doi:10.15185/glmlic.696.1
    publishDataset: Request was successful.
    publishDataset : {"status":"OK","data":{"id":351,"identifier":"glmlic.696.1","persistentUrl":"https://doi.org/10.15185/glmlic.696.1","protocol":"doi","authority":"10.15185","publisher":"DEV - Research Data Center of IZA (IDSC)","storageIdentifier":"local://10.15185/glmlic.696.1"}}
    ---------------------------
    Creating  doi:10.15185/j.geb.2022.10.008
    publishDataset: Request was successful.
    publishDataset : {"status":"OK","data":{"id":354,"identifier":"j.geb.2022.10.008","persistentUrl":"https://doi.org/10.15185/j.geb.2022.10.008","protocol":"doi","authority":"10.15185","publisher":"DEV - Research Data Center of IZA (IDSC)","storageIdentifier":"local://10.15185/j.geb.2022.10.008"}}
    ---------------------------
    Creating  doi:10.15185/glmlic.399.1
    publishDataset: Request was successful.
    publishDataset : {"status":"OK","data":{"id":357,"identifier":"glmlic.399.1","persistentUrl":"https://doi.org/10.15185/glmlic.399.1","protocol":"doi","authority":"10.15185","publisher":"DEV - Research Data Center of IZA (IDSC)","storageIdentifier":"local://10.15185/glmlic.399.1"}}
    ---------------------------
    Creating  doi:10.15185/izadp.7971.1
    publishDataset: Request was successful.
    publishDataset : {"status":"OK","data":{"id":360,"identifier":"izadp.7971.1","persistentUrl":"https://doi.org/10.15185/izadp.7971.1","protocol":"doi","authority":"10.15185","publisher":"DEV - Research Data Center of IZA (IDSC)","storageIdentifier":"local://10.15185/izadp.7971.1"}}
    ---------------------------
    Creating  doi:10.15185/glmlic.700.1
    publishDataset: Request was successful.
    publishDataset : {"status":"OK","data":{"id":363,"identifier":"glmlic.700.1","persistentUrl":"https://doi.org/10.15185/glmlic.700.1","protocol":"doi","authority":"10.15185","publisher":"DEV - Research Data Center of IZA (IDSC)","storageIdentifier":"local://10.15185/glmlic.700.1"}}
    ---------------------------
    Creating  doi:10.15185/glmlic.238.1
    publishDataset: Request was successful.
    publishDataset : {"status":"OK","data":{"id":367,"identifier":"glmlic.238.1","persistentUrl":"https://doi.org/10.15185/glmlic.238.1","protocol":"doi","authority":"10.15185","publisher":"DEV - Research Data Center of IZA (IDSC)","storageIdentifier":"local://10.15185/glmlic.238.1"}}
    ---------------------------
    Creating  doi:10.5072/FK2/LMCCQU
    publishDataset: Request was successful.
    publishDataset : {"status":"OK","data":{"id":370,"identifier":"FK2/LMCCQU","persistentUrl":"https://doi.org/10.5072/FK2/LMCCQU","protocol":"doi","authority":"10.5072","publisher":"DEV - Research Data Center of IZA (IDSC)","storageIdentifier":"local://10.5072/FK2/LMCCQU"}}
    ---------------------------
    Creating  doi:10.15185/glmlic.176.1
    publishDataset: Request was successful.
    publishDataset : {"status":"OK","data":{"id":371,"identifier":"glmlic.176.1","persistentUrl":"https://doi.org/10.15185/glmlic.176.1","protocol":"doi","authority":"10.15185","publisher":"DEV - Research Data Center of IZA (IDSC)","storageIdentifier":"local://10.15185/glmlic.176.1"}}
    ---------------------------
    Creating  doi:10.15185/glmlic.620.1
    publishDataset: Request was successful.
    publishDataset : {"status":"OK","data":{"id":374,"identifier":"glmlic.620.1","persistentUrl":"https://doi.org/10.15185/glmlic.620.1","protocol":"doi","authority":"10.15185","publisher":"DEV - Research Data Center of IZA (IDSC)","storageIdentifier":"local://10.15185/glmlic.620.1"}}
    ---------------------------
    Creating  doi:10.15185/glmlic.582.1
    publishDataset: Request was successful.
    publishDataset : {"status":"OK","data":{"id":376,"identifier":"glmlic.582.1","persistentUrl":"https://doi.org/10.15185/glmlic.582.1","protocol":"doi","authority":"10.15185","publisher":"DEV - Research Data Center of IZA (IDSC)","storageIdentifier":"local://10.15185/glmlic.582.1"}}
    ---------------------------
    Creating  doi:10.15185/glmlic.400.1
    publishDataset: Request was successful.
    publishDataset : {"status":"OK","data":{"id":378,"identifier":"glmlic.400.1","persistentUrl":"https://doi.org/10.15185/glmlic.400.1","protocol":"doi","authority":"10.15185","publisher":"DEV - Research Data Center of IZA (IDSC)","storageIdentifier":"local://10.15185/glmlic.400.1"}}
    ---------------------------
    Creating  doi:10.15185/izadp.8337.1
    publishDataset: Request was successful.
    publishDataset : {"status":"OK","data":{"id":381,"identifier":"izadp.8337.1","persistentUrl":"https://doi.org/10.15185/izadp.8337.1","protocol":"doi","authority":"10.15185","publisher":"DEV - Research Data Center of IZA (IDSC)","storageIdentifier":"local://10.15185/izadp.8337.1"}}
    ---------------------------
    Creating  doi:10.15185/glmlic.330.1
    publishDataset: Request was successful.
    publishDataset : {"status":"OK","data":{"id":384,"identifier":"glmlic.330.1","persistentUrl":"https://doi.org/10.15185/glmlic.330.1","protocol":"doi","authority":"10.15185","publisher":"DEV - Research Data Center of IZA (IDSC)","storageIdentifier":"local://10.15185/glmlic.330.1"}}
    ---------------------------
    Creating  doi:10.15185/izarr.126.1
    publishDataset: Request was successful.
    publishDataset : {"status":"OK","data":{"id":387,"identifier":"izarr.126.1","persistentUrl":"https://doi.org/10.15185/izarr.126.1","protocol":"doi","authority":"10.15185","publisher":"DEV - Research Data Center of IZA (IDSC)","storageIdentifier":"local://10.15185/izarr.126.1"}}
    ---------------------------
    Creating  doi:10.15185/glmlic.720466.1
    publishDataset: Request was successful.
    publishDataset : {"status":"OK","data":{"id":390,"identifier":"glmlic.720466.1","persistentUrl":"https://doi.org/10.15185/glmlic.720466.1","protocol":"doi","authority":"10.15185","publisher":"DEV - Research Data Center of IZA (IDSC)","storageIdentifier":"local://10.15185/glmlic.720466.1"}}
    ---------------------------
    Creating  doi:10.15185/izadp.15011.1
    publishDataset: Request was successful.
    publishDataset : {"status":"OK","data":{"id":393,"identifier":"izadp.15011.1","persistentUrl":"https://doi.org/10.15185/izadp.15011.1","protocol":"doi","authority":"10.15185","publisher":"DEV - Research Data Center of IZA (IDSC)","storageIdentifier":"local://10.15185/izadp.15011.1"}}
    ---------------------------
    Creating  doi:10.15185/izarr.123.1
    publishDataset: Request was successful.
    publishDataset : {"status":"OK","data":{"id":396,"identifier":"izarr.123.1","persistentUrl":"https://doi.org/10.15185/izarr.123.1","protocol":"doi","authority":"10.15185","publisher":"DEV - Research Data Center of IZA (IDSC)","storageIdentifier":"local://10.15185/izarr.123.1"}}
    ---------------------------
    Creating  doi:10.15185/glmlic.406.1
    publishDataset: Request was successful.
    publishDataset : {"status":"OK","data":{"id":400,"identifier":"glmlic.406.1","persistentUrl":"https://doi.org/10.15185/glmlic.406.1","protocol":"doi","authority":"10.15185","publisher":"DEV - Research Data Center of IZA (IDSC)","storageIdentifier":"local://10.15185/glmlic.406.1"}}
    ---------------------------
    Creating  doi:10.15185/glmlic.707.1
    publishDataset: Request was successful.
    publishDataset : {"status":"OK","data":{"id":404,"identifier":"glmlic.707.1","persistentUrl":"https://doi.org/10.15185/glmlic.707.1","protocol":"doi","authority":"10.15185","publisher":"DEV - Research Data Center of IZA (IDSC)","storageIdentifier":"local://10.15185/glmlic.707.1"}}
    ---------------------------
    Creating  doi:10.15185/glmlic.704.1
    publishDataset: Request was successful.
    publishDataset : {"status":"OK","data":{"id":408,"identifier":"glmlic.704.1","persistentUrl":"https://doi.org/10.15185/glmlic.704.1","protocol":"doi","authority":"10.15185","publisher":"DEV - Research Data Center of IZA (IDSC)","storageIdentifier":"local://10.15185/glmlic.704.1"}}


**Create/Publish/Delete dataverse**


```python
dev.createDataverse(name="Nikos' Repository", 
        alias="nikos", 
        dataverseContacts="nikos@askitas.com,askitas@iza.org",
        affiliation = "IZA - Institute of Labor Economics",
        description = "Metadata, Data and Code repository from Nikos Askitas's",
        dataverseType = "RESEARCHERS",
        parent = "G2LM-LIC"
        
       )

dev.createDataverse("nikos")
dev.publishDataverse("nikos")
dev.deleteDataverse("nikos")

```

    createDataverse Failed to create dataverse with status code: 403, {"status":"ERROR","message":"A dataverse with alias nikos already exists"}
    deleteDataverse: Successfully deleted dataverse nikos
    {"status":"OK","data":{"message":"Dataverse nikos deleted"}}



```python

```
